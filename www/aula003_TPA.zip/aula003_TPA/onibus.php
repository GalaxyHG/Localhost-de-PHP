<?php
    class Onibus extends Veiculo
    {

    }
?>