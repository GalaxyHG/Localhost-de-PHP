<?php
    class Carro extends Veiculo
    {
        
    }
?>