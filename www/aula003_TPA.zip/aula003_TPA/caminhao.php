<?php
    class Caminhao extends Veiculo
    {

    }
?>