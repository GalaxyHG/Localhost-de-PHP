<?php
    class Moto extends Veiculo
    {

    }
?>